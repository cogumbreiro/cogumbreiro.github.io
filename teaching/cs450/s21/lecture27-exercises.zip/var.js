var x;
console.log(x);