var x;
x = 10;
while (x) {
    console.log(x);
    x = x - 1;
}
